export interface Statistique_joueur {
    id_statistique_joueur: number;
    joueur_id: number;
    match:number;
    m: number;
    MJ: number;
    PPM:number;
    RPM: number;
    PdPM: number;
    MPM:number;
    EFF:number
}