export interface Joueur {
    id_joueur: number;
    nom: string;
    prenom: string;
    dtn: string;
    equipe_id: number;
}