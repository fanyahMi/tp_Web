export interface Equipe {
    id: number;
    libelle: string;
}



