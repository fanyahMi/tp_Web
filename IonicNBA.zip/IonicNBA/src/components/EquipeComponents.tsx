import {
  IonItem,
  IonLabel,
  IonNote,
} from '@ionic/react';

import { IonCard, IonCardContent, IonCardHeader, IonCardSubtitle, IonCardTitle } from '@ionic/react';


// import { ListEquipe } from '../data/equipe';
import './Equipe.css';
import React from 'react';
import { Equipe } from '../data/equipe';

interface EquipeData {
    list: Equipe[];
}

const List_Equipe: React.FC<EquipeData> = ({ list }) => {
  return (
    <>
      {list.map((equipe) => (
        <IonItem key={equipe.id} routerLink={`/detail/${equipe.id}`} detail={false}>
          <IonCard className='cadre'>
            <IonCardHeader>
              <IonCardTitle style={{ float: 'left' }}>{equipe.libelle}</IonCardTitle>
              <IonCardSubtitle>Equipe : {equipe.id}</IonCardSubtitle>
            </IonCardHeader>
          </IonCard>
        </IonItem>
      ))}
    </>
  );
};

export default List_Equipe;
