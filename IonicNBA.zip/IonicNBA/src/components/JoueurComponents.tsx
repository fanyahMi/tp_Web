import {
    IonIcon,
    IonItem,
    IonLabel,
    IonNote,
  } from '@ionic/react';
  
  import './Equipe.css';
  import React from 'react';
import { personCircle } from 'ionicons/icons';
import { Joueur } from '../data/joueur';

// import { getJoueursByEquipeId } from '../data/listEquipe';


  
export  interface Joueur_Data {
      idEquipe: number;
      ListJoueur: Joueur[];
  }
  const Joueur_Data: React.FC<Joueur_Data> = ({ idEquipe , ListJoueur }) => {
    const joueurs = ListJoueur.filter(joueur => joueur.equipe_id === idEquipe);
    return (
      <>
        {joueurs && joueurs.map(joueur => (
          <IonItem key={joueur.id_joueur} routerLink={`/infoJoueur/${joueur.id_joueur}`} detail={false}>
            <IonIcon aria-hidden="true" icon={personCircle} color="primary"></IonIcon>
            <IonLabel className="ion-text-wrap">
              <h2>
                {joueur.nom} {joueur.prenom}
                <span className="date">
                  <IonNote>Poids : {joueur.dtn}</IonNote>
                </span>
              </h2>
              <h3>
                To: <IonNote>Me</IonNote>
              </h3>
            </IonLabel>
          </IonItem>
        ))}
      </>
    );
  };
  
  export default Joueur_Data;
  