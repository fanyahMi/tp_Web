import React from 'react';
import {
  IonContent,
  IonHeader,
  IonToolbar,
  IonTitle,
  IonList,
  IonItem,
  IonLabel,
} from '@ionic/react';
import { Statistique_joueur } from '../data/statistique_joueur';

interface InfoJoueurData {
  idJoueur: number;
  Info: Statistique_joueur[]; 
}

const InfoJoueur_Data: React.FC<InfoJoueurData> = ({ idJoueur, Info }) => {
    // Filtrer les données pour ne garder que celles où joueur_id correspond à idJoueur
    const filteredInfo = Info.filter(info => info.joueur_id === idJoueur);
  
    return (
      <IonContent>
        <IonHeader>
          <IonToolbar>
            <IonTitle>Information Joueur</IonTitle>
          </IonToolbar>
        </IonHeader>
        <IonHeader>
          <IonToolbar>
            <IonTitle>{filteredInfo.length > 0 ? filteredInfo[0].joueur_id : ''}</IonTitle>
          </IonToolbar>
        </IonHeader>
  
        <IonList>
          <IonItem lines="full">
            <IonLabel>M</IonLabel>
            <IonLabel>MJ</IonLabel>
            <IonLabel>PPM</IonLabel>
            <IonLabel>RPM</IonLabel>
            <IonLabel>PdPM</IonLabel>
            <IonLabel>MPM</IonLabel>
            <IonLabel>EFF</IonLabel>
          </IonItem>
  
          {filteredInfo.map((info, index) => (
            <IonItem key={index} lines="full">
              <IonLabel>{info.m}</IonLabel>
              <IonLabel>{info.MJ}</IonLabel>
              <IonLabel>{info.PPM}</IonLabel>
              <IonLabel>{info.RPM}</IonLabel>
              <IonLabel>{info.PdPM}</IonLabel>
              <IonLabel>{info.MPM}</IonLabel>
              <IonLabel>{info.EFF}</IonLabel>
            </IonItem>
          ))}
        </IonList>
      </IonContent>
    );
};
  

export default InfoJoueur_Data;
