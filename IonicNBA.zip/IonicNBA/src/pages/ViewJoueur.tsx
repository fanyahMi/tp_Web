import { useState } from 'react';
import {
  IonBackButton,
  IonButtons,
  IonContent,
  IonHeader,
  IonList,
  IonPage,
  IonToolbar,
  useIonViewWillEnter,
} from '@ionic/react';
import { useParams } from 'react-router';
import './ViewMessage.css';
import { Equipe } from '../data/equipe';
import { Joueur } from '../data/joueur';
import Joueur_Data from '../components/JoueurComponents';

const ViewEquipe: React.FC = () => {
  const [ListJoueur, setListJoueur] = useState<Joueur[]>([]);
  const params = useParams<{ id: string }>();

  console.log(params);

  // Simulation de données pour les joueurs
  const dataJoueurs: Joueur[] = [
    { id_joueur: 1, nom: "Nom1", prenom: "Prenom1", dtn: "date1" , equipe_id:1},
    { id_joueur: 2, nom: "Nom2", prenom: "Prenom2", dtn: "date2", equipe_id:1 },
    { id_joueur: 3, nom: "Nom3", prenom: "Prenom3", dtn: "date3", equipe_id:1 },
    { id_joueur: 4, nom: "Nom77", prenom: "Prenom77", dtn: "date77", equipe_id:1 },
    { id_joueur: 5, nom: "Nom88", prenom: "Prenom88", dtn: "date88", equipe_id:2 },
    { id_joueur: 6, nom: "Nom4", prenom: "Prenom4", dtn: "date4", equipe_id:2 },
    { id_joueur: 7, nom: "Nom5", prenom: "Prenom5", dtn: "date5", equipe_id:2 },
    { id_joueur: 8, nom: "Nom6", prenom: "Prenom6", dtn: "date6", equipe_id:3 },
    { id_joueur: 9, nom: "Nom7", prenom: "Prenom7", dtn: "date7", equipe_id:2 },
    { id_joueur: 10, nom: "Nom8", prenom: "Prenom8", dtn: "date8", equipe_id:3 },
    { id_joueur: 11, nom: "Nom10", prenom: "Prenom10", dtn: "date10", equipe_id:4 },
    { id_joueur: 12, nom: "Nom11", prenom: "Prenom11", dtn: "date11", equipe_id:4 },
    { id_joueur: 13, nom: "Nom9", prenom: "Prenom9", dtn: "date9", equipe_id:4 }
    
  ];

  useIonViewWillEnter(() => {
    setListJoueur(dataJoueurs); // Mettre à jour la liste des joueurs avec les données simulées
  });

  const refresh = (e: CustomEvent) => {
    setTimeout(() => {
      e.detail.complete();
    }, 3000);
  };

  return (
    <IonPage id="view-message-page">
      <IonHeader translucent>
        <IonToolbar>
          <IonButtons slot="start">
            <IonBackButton text="Liste des Equipe" defaultHref="/home" />
          </IonButtons>
        </IonToolbar>
      </IonHeader>
      <IonContent fullscreen>
        <Joueur_Data idEquipe={parseInt(params.id, 10)} ListJoueur={dataJoueurs} />
        <IonList></IonList>
      </IonContent>
    </IonPage>
  );
};

export default ViewEquipe;
