import MessageListItem from '../components/MessageListItem';
import EquipeData from '../components/EquipeComponents';
import { useEffect, useState } from 'react';
// import { ListEquipe, getEquipe, getListe } from '../data/listEquipe';
import {
  IonContent,
  IonHeader,
  IonList,
  IonPage,
  IonRefresher,
  IonRefresherContent,
  IonTitle,
  IonToolbar,
  useIonViewWillEnter,
  IonInfiniteScroll,
  IonInfiniteScrollContent
} from '@ionic/react';
import './Home.css';
import List_Equipe from '../components/EquipeComponents';
import { Equipe } from '../data/equipe';

const Home: React.FC = () => {

  const [listes, setMessages] = useState<Equipe[]>([]);

  useIonViewWillEnter(() => {
    const msgs = [
      {id: 1 , libelle: "Equipe1"},
      {id: 2 , libelle: "Equipe2"},
      {id: 3 , libelle: "Equipe3"},
      {id: 4 , libelle: "Equipe4"}
    ];
    setMessages(msgs);
  });

  const refresh = (e: CustomEvent) => {
    setTimeout(() => {
      e.detail.complete();
    }, 3000);
  };

  // useEffect(() => {
  //   generateItems();
  //   // eslint-disable-next-line react-hooks/exhaustive-deps
  // }, []);

  return (

    <IonPage id="home-page">
      <IonHeader>
        <IonToolbar>
          <IonTitle>Listes des equipes de la ligue</IonTitle>
        </IonToolbar>
      </IonHeader>
      <IonContent fullscreen>
        <IonRefresher slot="fixed" onIonRefresh={refresh}>
          <IonRefresherContent></IonRefresherContent>
        </IonRefresher>

        <IonList>
            <List_Equipe list={listes}/>
        </IonList>
      </IonContent>
    </IonPage>
  );
};

// export default Home;
// function generateItems() {
//   throw new Error('Function not implemented.');
// }

// const Home: React.FC = () => {
//   const [listes, setListes] = useState<ListEquipe[]>([]);

//   useEffect(() => {
//     const fetchData = async () => {
//       try {
//         const response = await fetch('http://back-nba.000.pe/backnba/equipes'); // Remplacez par l'URL de votre service web
//         if (!response.ok) {
//           throw new Error('Failed to fetch data from the web service.');
//         }

//         const data: ListEquipe[] = await response.json();
//         console.log(response.json());
//         setListes(data); // Mettre à jour l'état avec les données récupérées du service web
//       } catch (error) {
//         console.error('Error fetching data from the web service:', error);
//       }
//     };

//     fetchData(); // Appeler la fonction pour récupérer les données au montage du composant
//   }, []); // Le tableau vide [] en tant que deuxième argument pour exécuter cette fonction une seule fois au montage du composant

//   const refresh = (e: CustomEvent) => {
//     setTimeout(() => {
//       e.detail.complete();
//     }, 3000);
//   };

//   return (
//     <IonPage id="home-page">
//       <IonHeader>
//         <IonToolbar>
//           <IonTitle>Listes des equipes de la ligue</IonTitle>
//         </IonToolbar>
//       </IonHeader>
//       <IonContent fullscreen>
//         <IonRefresher slot="fixed" onIonRefresh={refresh}>
//           <IonRefresherContent></IonRefresherContent>
//         </IonRefresher>

//         <IonList>
//           {listes.map(m => (
//             <List_Equipe key={m.id} list={m} />
//           ))}
//         </IonList>
//       </IonContent>
//     </IonPage>
//   );
// };

export default Home;
