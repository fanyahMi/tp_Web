import { useState } from 'react';
import {
  IonBackButton,
  IonButtons,
  IonContent,
  IonHeader,
  IonList,
  IonPage,
  IonToolbar,
  useIonViewWillEnter,
} from '@ionic/react';
import { useParams } from 'react-router';
import './ViewMessage.css';
import { Equipe } from '../data/equipe';
import { Joueur } from '../data/joueur';
import Joueur_Data from '../components/JoueurComponents';
import InfoJoueur_Data from '../components/InfoJoueurComponents';
import { Statistique_joueur } from '../data/statistique_joueur';

const ViewInfoJoueur: React.FC = () => {
  const [ListJoueur, setListJoueur] = useState<Joueur[]>([]);
  const params = useParams<{ id: string }>();

  console.log(params);

  // Simulation de données pour les joueurs
  const dataJoueurs: Statistique_joueur[] = [
    { id_statistique_joueur: 1,m: 1,joueur_id: 1,match:1, MJ: 1,PPM: 20 , RPM:13 , PdPM:18 , MPM:45,EFF: 13},
    { id_statistique_joueur: 2,m: 1,joueur_id:  2,match:1, MJ: 1,PPM: 12 , RPM:13 , PdPM:18 , MPM:45,EFF: 13},
    { id_statistique_joueur: 3,m: 2,joueur_id: 3,match:1, MJ: 2,PPM: 13 , RPM:13 , PdPM:18 , MPM:45,EFF: 13},
    { id_statistique_joueur: 4,m: 2,joueur_id: 4,match:2, MJ: 2,PPM: 16, RPM:13 , PdPM:18 , MPM:45,EFF: 13},
    { id_statistique_joueur: 5,m: 2,joueur_id: 5,match:2, MJ: 3,PPM: 14, RPM:13 , PdPM:18 , MPM:45,EFF: 13},
    { id_statistique_joueur: 6,m: 3,joueur_id: 6,match:2, MJ: 3,PPM: 7 , RPM:13 , PdPM:18 , MPM:45,EFF: 13},
    { id_statistique_joueur: 7,m: 3,joueur_id: 7,match:2, MJ: 4,PPM: 8 , RPM:13 , PdPM:18 , MPM:45,EFF: 13},
    { id_statistique_joueur: 8,m: 2,joueur_id: 8,match:3, MJ: 5,PPM: 7 , RPM:13 , PdPM:18 , MPM:45,EFF: 13},
    { id_statistique_joueur: 9,m: 2,joueur_id: 9,match:3, MJ: 6,PPM: 8 , RPM:13 , PdPM:18 , MPM:45,EFF: 13},
    { id_statistique_joueur: 10,m:1,joueur_id: 10,match:4, MJ: 7,PPM: 7 , RPM:13 , PdPM:18 , MPM:45,EFF: 13},
    { id_statistique_joueur: 11,m: 4,joueur_id: 11,match:4, MJ: 8,PPM: 8 , RPM:12 , PdPM:18 , MPM:45,EFF: 13},
    { id_statistique_joueur: 12,m: 4,joueur_id: 12,match:4, MJ: 9,PPM: 7 , RPM:16 , PdPM:18 , MPM:45,EFF: 13},
    { id_statistique_joueur: 13,m: 4,joueur_id: 13,match:4, MJ: 10,PPM: 8 , RPM:15 , PdPM:18 , MPM:45,EFF: 13},
    { id_statistique_joueur: 14,m: 1,joueur_id: 1,match:1, MJ: 1,PPM: 20 , RPM:13 , PdPM:18 , MPM:45,EFF: 13},
    { id_statistique_joueur: 15,m: 1,joueur_id:  2,match:1, MJ: 1,PPM: 12 , RPM:13 , PdPM:18 , MPM:45,EFF: 13},
    { id_statistique_joueur: 16,m: 2,joueur_id: 3,match:1, MJ: 2,PPM: 13 , RPM:13 , PdPM:18 , MPM:45,EFF: 13},
    { id_statistique_joueur: 17,m: 2,joueur_id: 4,match:2, MJ: 2,PPM: 16, RPM:13 , PdPM:18 , MPM:45,EFF: 13},
    { id_statistique_joueur: 18,m: 2,joueur_id: 5,match:2, MJ: 3,PPM: 14, RPM:13 , PdPM:18 , MPM:45,EFF: 13},
    { id_statistique_joueur: 19,m: 3,joueur_id: 6,match:2, MJ: 3,PPM: 7 , RPM:13 , PdPM:18 , MPM:45,EFF: 13},
    { id_statistique_joueur: 20,m: 3,joueur_id: 7,match:2, MJ: 4,PPM: 8 , RPM:13 , PdPM:18 , MPM:45,EFF: 13},
    { id_statistique_joueur: 21,m: 2,joueur_id: 8,match:3, MJ: 5,PPM: 7 , RPM:13 , PdPM:18 , MPM:45,EFF: 13},
    { id_statistique_joueur: 22,m: 2,joueur_id: 9,match:3, MJ: 6,PPM: 8 , RPM:13 , PdPM:18 , MPM:45,EFF: 13},
    { id_statistique_joueur: 23,m:1,joueur_id: 10,match:4, MJ: 7,PPM: 7 , RPM:13 , PdPM:18 , MPM:45,EFF: 13},
    { id_statistique_joueur: 24,m: 4,joueur_id: 11,match:4, MJ: 8,PPM: 8 , RPM:12 , PdPM:18 , MPM:45,EFF: 13},
    { id_statistique_joueur: 25,m: 4,joueur_id: 12,match:4, MJ: 9,PPM: 7 , RPM:16 , PdPM:18 , MPM:45,EFF: 13},
    { id_statistique_joueur: 26,m: 4,joueur_id: 13,match:4, MJ: 10,PPM: 8 , RPM:15 , PdPM:18 , MPM:45,EFF: 13}
];

//   useIonViewWillEnter(() => {
//     setListJoueur(dataJoueurs); // Mettre à jour la liste des joueurs avec les données simulées
//   });

  const refresh = (e: CustomEvent) => {
    setTimeout(() => {
      e.detail.complete();
    }, 3000);
  };

  return (
    <IonPage id="view-message-page">
      <IonHeader translucent>
        <IonToolbar>
          <IonButtons slot="start">
            <IonBackButton text="Liste de joueur" defaultHref="/home" />
          </IonButtons>
        </IonToolbar>
      </IonHeader>
      <IonContent fullscreen>
        <InfoJoueur_Data idJoueur={parseInt(params.id, 10)} Info={dataJoueurs} />
        <IonList></IonList>
      </IonContent>
    </IonPage>
  );
};

export default ViewInfoJoueur;
